$(function () {
	
	$('.report-cirque').cirque ({
		radius: 60,
		total: 7630,
		lineWidth: 10,
		trackColor: '#CCCCCC',
	});
	
});