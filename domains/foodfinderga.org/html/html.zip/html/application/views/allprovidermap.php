<div class="full-wdith">
	<div class="desktop-bg">
    	<div class="login-bg">
        <div class="schoolresultmap_page">
        <div style="float:left"><a href="<?php echo site_url();?>school"><img src="<?php echo base_url(); ?>img/front/close.png" alt="close" width="70%" height="70%"></a></div>
          	<div style="padding-top:3px;" align="center"></div>
            <div class="schoolresult_map">
            <?php echo $map['js']; ?>
            <?php echo $map['html']; ?>
            </div>
            <div style="clear:both; height:20px;"><!-- --></div>
            <div align="center" class="footer-text"><a href="#">About Us</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#">Other Resources</a></div>
        </div></div>
        <div style="clear:both;"><!-- --></div>
	</div>
</div>
