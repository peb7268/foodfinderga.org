<div class="full-wdith">
	<div class="desktop-bg">
    	<div class="login-bg">
        	<div class="schoolprovider_page">
			
            
            <div style="float:left"><a href="<?php echo $_SERVER['HTTP_REFERER']; ?>"><img src="<?php echo base_url(); ?>img/front/close.png" alt="close" width="70%" height="70%"></a></div>
			<div class="provider_result1">
           	<div class="provider_result1">No Providers are available near this school</div>
            </div>
            <div style="clear:both; height:20px;"><!-- --></div>
            <div align="center" class="footer-text"><a href="https://twitter.com/FoodFinderGA" target="blank">Follow Us On: <img src="<?php echo base_url(); ?>img/front/twitter_iconsm.png"/></a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url(); ?>school/aboutus">About Us</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url(); ?>school/other_resources">Other Resources</a></div>
        </div></div>
        <div style="clear:both;"><!-- --></div>
	</div>
</div>
