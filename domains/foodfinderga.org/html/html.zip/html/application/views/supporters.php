<div class="full-wdith">
    <div class="desktop-bg">
        <div class="login-bg">            
            <div style="padding-top:3%;padding-bottom: 2%;" align="center"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>img/front/logo.png" border="0" class="img-responsive" ></a></div>
            <div align="center" class="homefont">Welcome to Food Finder GA</div>            
            <div align="center" class="homefont1">The easiest and fastest way to find food resources in Gwinnett County.</div>
            <div class="footer-bg clearfix">
            <div class="term_condition_wrap supporters_wrap">
                <h4>CONTRIBUTORS</h4>
                <h5>THANK YOU to everyone who made this website possible!</h5>
                <ul>
                <li>A J Brustein</li>
                <li>Anthony Doctolero</li>
                <li>Brennan Demro</li>
                <li>Brooke L Robel</li>
                <li>Carol Martin</li>
                <li>Chris Borek</li>
                <li>Chuck Billups</li>
                <li>D Scott Karnedy</li>
                <li>Dan Dillon</li>
                <li>Dana L Cilla</li>
                <li>Darby Williams</li>
                <li>David & Kelah McNeill</li>
                <li>David C. Will</li>
                <li>David G Dalton</li>
                <li>David Metter</li>
                <li>Gwen Morrison Porter</li>
                <li>Harmon B Miller</li>
                <li>Jamie Wiley</li>
                <li>Jeanine Forini</li>               
                <li>Jeff & Deb Hughes</li>               
                <li>Jim & Irene Baughman</li>               
                <li>Jim Leland</li>               
                <li>Joan Segal</li>               
                <li>John & Lori Jacobi</li>               
                <li>John Mecklenburg</li>               
                <li>John White</li>               
                <li>Jonathan Rosenbaum</li>               
                <li>Julie Paulk Walker</li>               
                <li>Karla Haley</li>               
                <li>Kimberly Knudson</li>               
                <li>Lisa Fey</li>
                <li>Mark White</li>
                <li>Matt Downey</li>
                <li>Michael Anderson</li>
                <li>Michael La Kier</li>
                <li>Michael Stern</li>
                <li>Mike & Karen Sweeney</li>
                <li>Mike Williamson</li>
                <li>Nick Karebian</li>
                <li>Penny Oglesby Cruise</li>
                <li>Premier Construction of Illinois</li>
                <li>Rachel Park</li>
                <li>Renu Gupta</li>
                <li>Rick Lowenstein</li>
                <li>Roberto Welcome</li>
                <li>Samantha Holler</li>
                <li>Sharon A. Fordham</li>
                <li>Steve M. Haverly</li>
                <li>Steven Prebble</li>
                <li>Stuart Fierman</li>
                <li>Suzanne Law</li>
                <li>Tammy Kay Hurt</li>
                <li>Tara Karebian</li>
                <li>Teri L Schneider</li>
                <li>Terrie Karebian</li>
                <li>Timothy J Tonella</li>
                <li>Todd Steele</li>
                </ul>

            </div>
          <?php include('footer_menu.php'); ?>
            </div>

        </div>
    </div>
</div>

