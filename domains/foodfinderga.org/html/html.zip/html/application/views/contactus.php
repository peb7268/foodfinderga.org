<div class="full-wdith">
    <div class="desktop-bg">
        <div class="login-bg">            
            <div style="padding-top:3%;padding-bottom: 2%;" align="center"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>img/front/logo.png" border="0" class="img-responsive" ></a></div>
            <div align="center" class="homefont">Welcome to Food Finder GA</div>            
            <div align="center" class="homefont1">The easiest and fastest way to find food resources in Gwinnett County.</div>
            <div class="footer-bg clearfix">
                <div class="back_icon"><a onclick="window.history.back()"><img src="<?php echo base_url(); ?>img/front/close.png" alt="close" width="80%" height="80%"></a></div><div class="home_iconn"><a href="<?php echo base_url();?>"><img src="<?php echo base_url();?>img/front/homeicon.png"/></a></div>
            <div class="termpad_wrap contactus_wrap">
                <h2 style="text-align: center">Contact Us</h2>
                <h4 style="text-align: center"><a href="mailto:info@foodfinderga.org">info@foodfinderga.org</a></h4>
            </div>
<?php include('footer_menu.php'); ?>
            </div>

        </div>
    </div>
</div>

