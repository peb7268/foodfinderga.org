<link rel="stylesheet" href="<?php echo base_url();?>foodfinderga/dashboard.css">
<div id="content">
<div class="container">
		<div style="min-height:550px;">
	      <div class="row">	      	
	      	<div class="span12">	      		
	      		<div class="widget">						
					<div class="widget-header">
						<i class="icon-star"></i>
						<h3>Dashboard</h3>
					</div> <!-- /widget-header -->					
					<div class="widget-content" style="height:320px;">					
                    <div id="pie-chart" class="chart-holder"></div>							
					</div> <!-- /widget-content -->						
				</div> <!-- /widget -->
		    </div> <!-- /span6 -->
	      </div> <!-- /row -->
		</div>
	    </div><!-- /.container -->
</div>