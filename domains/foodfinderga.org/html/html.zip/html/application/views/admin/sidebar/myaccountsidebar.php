					
					<!--  Trainer side menu -->
                    <ul class="nav nav-tabs nav-stacked">
						<li class="<?php if($pageName=="changepassword") { echo "active"; } ?>">
							<a href="<?php echo site_url('admin/changepassword'); ?>">
								<i class="icon-plus"></i>
								Change Password
								<i class="icon-chevron-right"></i>
								
							</a>              		
						</li>
                   
					</ul>
					