<script src="<?php echo base_url();?>js/libs/jquery-1.7.2.min.js"></script>
<script src="<?php echo base_url();?>js/jquery.confirm.js"></script>
<script defer src="<?php echo base_url();?>foodfinderga/common.js" type="text/javascript" language="javascript"></script>
<script defer src="<?php echo base_url();?>js/libs/jquery-ui-1.8.21.custom.min.js"></script>
<script defer src="<?php echo base_url();?>js/libs/jquery.ui.touch-punch.min.js"></script>
<script defer src="<?php echo base_url();?>js/libs/bootstrap/bootstrap.min.js"></script>
<script defer src="<?php echo base_url();?>js/Theme.js"></script>
<script defer src="<?php echo base_url();?>js/Application.js"></script>
<script defer src="<?php echo base_url();?>js/plugins/validate/jquery.validate.js"></script>
<script defer src="<?php echo base_url();?>js/plugins/validate/additional-methods.js"></script>
<script defer src="<?php echo base_url();?>foodfinderga/plugins/tooltip/bootstrap-tooltip.js"></script>
<script defer src="<?php echo base_url();?>css/msgGrowl/js/msgGrowl.js" type="text/javascript" language="javascript"></script>
</body>
</html>