<div class="full-wdith">
    <div class="desktop-bg">
        <div class="login-bg">            
            <div style="padding-top:3%;padding-bottom: 2%;" align="center"><a href="<?php echo base_url(); ?>"><img src="<?php echo base_url(); ?>img/front/logo.png" border="0" class="img-responsive" ></a></div>
            <div align="center" class="homefont">Welcome to Food Finder GA</div>            
            <div align="center" class="homefont1">The easiest and fastest way to find food resources in Gwinnett County.</div>
            <div class="footer-bg clearfix">
            <div class="term_condition_wrap">
                <p>Furthermore, no delay or omission by FoodFinder to exercise any right or any noncompliance on your part with respect to the Terms shall impair any such right or be construed to be a waiver by FoodFinder. If any provision of the Terms is found by a court of competent jurisdiction to be invalid or unenforceable in whole or in part, such provision shall, as to such jurisdiction, be ineffective to the extent of such invalidity or unenforceability without in any manner affecting the validity or enforceability thereof in any other jurisdiction or the remaining provisions hereof in any jurisdiction, provided, however, if such invalid or unenforceable provision may be modified so as to be valid and enforceable as a matter of law, such provision will be deemed to have been modified so as to be valid and enforceable to the maximum extent permitted by law.</p>
            </div>
            <div align="center" class="footer-text">
            <a href="<?php echo base_url();?>school/terms_conditions">Terms and Conditions</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="<?php echo base_url();?>school/privacypolicy">Privacy Policy</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;<a href="#">Contact Us</a></div>
            </div>

        </div>
    </div>
</div>

